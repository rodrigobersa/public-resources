variable "name_prefix" {
  description = "Prefix for the environemnt and Amazon EKS Cluster names"
  type        = string
  default     = "amazon-eks"
}

variable "region" {
  description = "AWS Region to deploy the environemnt"
  type        = string
  default     = "us-west-2"
}

variable "cluster_version" {
  description = "Amazon EKS Kubernetes version. Defaults to `1.29`"
  type        = string
  default     = "1.32"
}

variable "cidr_block" {
  type        = string
  default     = "10.0.0.0/16"
  description = "The CIDR block for the VPC"
}

variable "secondary_cidr_block" {
  type        = string
  default     = "100.0.0.0/16"
  description = "The CIDR block for the VPC"
}

variable "karpenter_crds" {
  type    = list(string)
  default = ["ec2nodeclasses.karpenter.k8s.aws", "nodepools.karpenter.sh", "nodeclaims.karpenter.sh"]
}

variable "admin_user_config" {
  description = "Configuration for Platform Admin Users."
  type = list(object({
    family_name = string
    given_name  = string
    email       = string
  }))
  default = [{
    family_name = "Admin"
    given_name  = "Platform"
    email       = "admin@example.com"
  }]
}

variable "user_config" {
  description = "Configuration for Developer Users."
  type = list(object({
    family_name = string
    given_name  = string
    email       = string
  }))
  default = [{
    family_name = "User1"
    given_name  = "Developer"
    email       = "user1@example.com"
    },
    {
      family_name = "User2"
      given_name  = "Developer"
      email       = "user2@example.com"
    }
  ]
}