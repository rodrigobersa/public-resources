# Amazon EKS Cluster deployment with Terraform

The following guidance, deploys an Amazon EKS Cluster in a new VPC with the majority of add-ons required to map OpenShift standard functionalities, i.e. Routers, Storage, Metrics, and Overlay network.

## Deploy the solution

To deploy this blueprint, follow the below steps.

1. Clone this repository if you didn't do it already.

    ```sh
    git clone https://github.com/aws-samples/red-hat-ocp-v4-to-amazon-eks
    cd red-hat-ocp-v4-to-amazon-eks/eks-cluster/terraform
    ```

2. Run the following Terraform commands to initialize and deploy the basic stack with the new VPC and the Amazon EKS Cluster.

    ```sh
    terraform init
    terraform apply -target="module.vpc" -auto-approve
    terraform apply -target="module.eks" -auto-approve
    ```

3. In order to create the Custom Networking configuration that will act similarly to OpenShift's overlay network with a secondary CIDR block dedicated to Pods, uncomment the following lines on the `vpc.tf` file.

    ```sh
    resource "kubernetes_manifest" "eni_config" {
        for_each = zipmap(local.azs, slice(module.vpc.private_subnets, 4, 8))
          manifest = {
            apiVersion = "crd.k8s.amazonaws.com/v1alpha1"
            kind       = "ENIConfig"
            metadata = {
            name = each.key
            }
            spec = {
                securityGroups = [
                module.eks.node_security_group_id,
                ]
                subnet = each.value
            }
        }
    }
    ```

    > These lines are commented because the `kubernetes_manifest` resource, requires a running cluster, so Terraform is able to interpolate the manifest.

4. Now that the cluster is up, deploy the additional add-ons like, Load Balancer Controller, EFS CSI Provider, Cert-Manager, Metrics Server, Karpenter, and Secrets CSI Provider, with all the remaining resources and dependencies.

   ```sh
    terraform apply -target="module.karpenter" -target="module.karpenter_addon" -target="module.eks_blueprints_addons" -auto-approve
    terraform apply -target="module.efs" -target="module.ebs_kms_key" -auto-approve
    terraform apply -auto-approve
    ```

5. Validate the deployment, use the Terraform output to update your `kubeconfig` file with the Amazon EKS `cluster-admin` credentials, and check the status of the running Pods.

    ```sh
    terraform output -raw configure_kubectl | bash
    kubectl get pods -A
    ```

    The output should look similar to the one below.

    ```sh
    NAMESPACE                 NAME                                            READY   STATUS    RESTARTS   AGE
    brupop-bottlerocket-aws   brupop-agent-2bddz                              1/1     Running   0          4h
    brupop-bottlerocket-aws   brupop-agent-bwkdk                              1/1     Running   0          4h
    brupop-bottlerocket-aws   brupop-agent-z8p6r                              1/1     Running   0          4h
    brupop-bottlerocket-aws   brupop-apiserver-6b4666567d-bkzl2               1/1     Running   0          4h
    brupop-bottlerocket-aws   brupop-apiserver-6b4666567d-gqq48               1/1     Running   0          4h
    brupop-bottlerocket-aws   brupop-apiserver-6b4666567d-vvrlp               1/1     Running   0          4h
    brupop-bottlerocket-aws   brupop-controller-deployment-77f8d576d9-zh582   1/1     Running   0          4h
    cert-manager              cert-manager-5b895cddbb-fzphl                   1/1     Running   0          4h
    cert-manager              cert-manager-cainjector-7f6c98d568-d7ttx        1/1     Running   0          4h
    cert-manager              cert-manager-webhook-7d4465dd8b-xxnbd           1/1     Running   0          4h
    kube-system               aws-load-balancer-controller-5468cd9d57-6tlfp   1/1     Running   0          4h
    kube-system               aws-load-balancer-controller-5468cd9d57-zqb2z   1/1     Running   0          4h
    kube-system               aws-node-4pg5v                                  2/2     Running   0          4h
    kube-system               aws-node-z2lk8                                  2/2     Running   0          4h
    kube-system               aws-node-zcks5                                  2/2     Running   0          4h
    kube-system               coredns-599f7d65c5-chhlp                        1/1     Running   0          4h
    kube-system               coredns-599f7d65c5-xwwjl                        1/1     Running   0          4h
    kube-system               ebs-csi-controller-657cc4ffbc-8kvj4             6/6     Running   0          4h
    kube-system               ebs-csi-controller-657cc4ffbc-glrn7             6/6     Running   0          4h
    kube-system               ebs-csi-node-8wqkn                              3/3     Running   0          4h
    kube-system               ebs-csi-node-qkt4v                              3/3     Running   0          4h
    kube-system               ebs-csi-node-qtxls                              3/3     Running   0          4h
    kube-system               efs-csi-controller-7b7c4c4796-hxgsp             3/3     Running   0          4h
    kube-system               efs-csi-controller-7b7c4c4796-jmhxs             3/3     Running   0          4h
    kube-system               efs-csi-node-jbqvt                              3/3     Running   0          4h
    kube-system               efs-csi-node-qn8x2                              3/3     Running   0          4h
    kube-system               efs-csi-node-wbqdz                              3/3     Running   0          4h
    kube-system               eks-pod-identity-agent-6svmb                    1/1     Running   0          4h
    kube-system               eks-pod-identity-agent-bqxbv                    1/1     Running   0          4h
    kube-system               eks-pod-identity-agent-kbbz8                    1/1     Running   0          4h
    kube-system               karpenter-5c5646d67b-k9tgj                      1/1     Running   0          4h
    kube-system               karpenter-5c5646d67b-mj2qr                      1/1     Running   0          4h
    kube-system               kube-proxy-5gc7d                                1/1     Running   0          4h
    kube-system               kube-proxy-mvh47                                1/1     Running   0          4h
    kube-system               kube-proxy-tdgxh                                1/1     Running   0          4h
    kube-system               metrics-server-76dfb8cb4b-9qxvs                 1/1     Running   0          4h
    kube-system               metrics-server-76dfb8cb4b-j64k6                 1/1     Running   0          4h
    kube-system               secrets-store-csi-driver-provider-aws-6xkpc     1/1     Running   0          4h
    kube-system               secrets-store-csi-driver-provider-aws-nj4q6     1/1     Running   0          4h
    kube-system               secrets-store-csi-driver-provider-aws-zbvqr     1/1     Running   0          4h
    kube-system               secrets-store-csi-driver-qdk84                  3/3     Running   0          4h
    kube-system               secrets-store-csi-driver-rv5sl                  3/3     Running   0          4h
    kube-system               secrets-store-csi-driver-skns4                  3/3     Running   0          4h
    ```

6. You may also need to validate the users created with the AWS Identity Center integration. In order to do that, there are two Terraform outputs that can be used.

    You'll need to set, reset or have the users password in order to do that. If you didn't set that already, in the [IAM Identity Center Console](https://us-west-2.console.aws.amazon.com/singlesignon/home), you can reset the user password.

    ![SSOResetPasswd](../../static/images/sso.png "SSOResetPasswd")

   1. To validate the users with **admin** permission, you'll need to configure your SSO profile like the following. In this example the admins belong to the `eks-operators` group on Identity Center, you use the `configure_sso_admins` output as below, it should return all the required information to set up.

        ```sh
        terraform output -raw configure_sso_admins
            SSO session name (Recommended): EKSClusterAdmin-$ACCOUNT_ID
            SSO start URL [None]: https://d-1234567890.awsapps.com/start
            SSO region [None]: us-west-2
            SSO registration scopes [sso:account:access]:
            Attempting to automatically open the SSO authorization page in your default browser.
            If the browser does not open or you wish to use a different device to authorize this request, open the following URL:

            The only AWS account available to you is: $ACCOUNT_ID
            Using the account ID $ACCOUNT_ID
            The only role available to you is: EKSClusterAdmin
            Using the role name "EKSClusterAdmin"
            CLI default client Region [None]: us-west-2
            CLI default output format [None]: json

            To use this profile, specify the profile name using --profile, as shown:

            aws eks --region us-west-2 update-kubeconfig --name $CLUSTER_NAME --profile EKSClusterAdmin-$ACCOUNT_ID
        ```

        Run the following command, follow the instructions on the CLI filling with the information from the previous step.

        ```sh
        aws configure sso --profile EKSClusterAdmin-$ACCOUNT_ID
        ```

        Validate the scoped access to the **admin** user.

        ``` sh
        aws eks --region us-west-2 update-kubeconfig --name $CLUSTER_NAME --profile EKSClusterAdmin-$ACCOUNT_ID
        kubectl get pods -A
        ```

        > The output should be the same as the `cluster-admin` shown previously.

   2. To validate the users with **user** permission, you'll need to configure your SSO profile like the following. In this example the users belong to the `eks-developers` group on Identity Center, you use the `configure_sso_users` output as below, it should return all the required information to set up.

       ```sh
        terraform output -raw configure_sso_users
            SSO session name (Recommended): EKSClusterUser-$ACCOUNT_ID
            SSO start URL [None]: https://d-1234567890.awsapps.com/start
            SSO region [None]: us-west-2
            SSO registration scopes [sso:account:access]:
            Attempting to automatically open the SSO authorization page in your default browser.
            If the browser does not open or you wish to use a different device to authorize this request, open the following URL:

            The only AWS account available to you is: $ACCOUNT_ID
            Using the account ID $ACCOUNT_ID
            The only role available to you is: EKSClusterUser
            Using the role name "EKSClusterUser"
            CLI default client Region [None]: us-west-2
            CLI default output format [None]: json

            To use this profile, specify the profile name using --profile, as shown:

            aws eks --region us-west-2 update-kubeconfig --name $CLUSTER_NAME --profile EKSClusterUser-$ACCOUNT_ID
        ```

        Run the following command, follow the instructions on the CLI filling with the information from the previous step.

        ```sh
        aws configure sso --profile EKSClusterUser-$ACCOUNT_ID
        ```

        Validate the scoped access to the **user**.

        ``` sh
        aws eks --region us-west-2 update-kubeconfig --name $CLUSTER_NAME --profile EKSClusterUser-$ACCOUNT_ID
        kubectl get pods -A
        ```

        Since the user access is scoped, it shouldn't have access to list Pods on all Namespaces.

        ```sh
        Error from server (Forbidden): pods is forbidden: User "arn:aws:sts::$ACCOUNT_ID$:assumed-role/AWSReservedSSO_EKSClusterUser_cd8c1929911e33f8/user1-example.com" cannot list resource "pods" in API group "" at the cluster scope
        ```

        Try to list resources on the `default`, `development`, and `kube-system` Namespaces.

        ```sh
        kubectl get ns                
            NAME                      STATUS   AGE
            brupop-bottlerocket-aws   Active   4h
            cert-manager              Active   4h
            default                   Active   4h
            development               Active   4h
            kube-node-lease           Active   4h
            kube-public               Active   4h
            kube-system               Active   4h
        kubectl get all -n default                                
            NAME                 TYPE        CLUSTER-IP   EXTERNAL-IP   PORT(S)   AGE
            service/kubernetes   ClusterIP   172.20.0.1   <none>        443/TCP   4h
        kubectl get all -n development
            No resources found in development namespace.
        kubectl get all -n kube-system
            Error from server (Forbidden): pods is forbidden: User "arn:aws:sts::$ACCOUNT_ID:assumed-role/AWSReservedSSO_EKSClusterUser_cd8c1929911e33f8/user1-example.com" cannot list resource "pods" in API group "" in the namespace "kube-system"
            Error from server (Forbidden): replicationcontrollers is forbidden: User "arn:aws:sts::$ACCOUNT_ID:assumed-role/AWSReservedSSO_EKSClusterUser_cd8c1929911e33f8/user1-example.com" cannot list resource "replicationcontrollers" in API group "" in the namespace "kube-system"
            Error from server (Forbidden): services is forbidden: User "arn:aws:sts::$ACCOUNT_ID:assumed-role/AWSReservedSSO_EKSClusterUser_cd8c1929911e33f8/user1-example.com" cannot list resource "services" in API group "" in the namespace "kube-system"
            Error from server (Forbidden): daemonsets.apps is forbidden: User "arn:aws:sts::$ACCOUNT_ID:assumed-role/AWSReservedSSO_EKSClusterUser_cd8c1929911e33f8/user1-example.com" cannot list resource "daemonsets" in API group "apps" in the namespace "kube-system"
            Error from server (Forbidden): deployments.apps is forbidden: User "arn:aws:sts::$ACCOUNT_ID:assumed-role/AWSReservedSSO_EKSClusterUser_cd8c1929911e33f8/user1-example.com" cannot list resource "deployments" in API group "apps" in the namespace "kube-system"
            Error from server (Forbidden): replicasets.apps is forbidden: User "arn:aws:sts::$ACCOUNT_ID:assumed-role/AWSReservedSSO_EKSClusterUser_cd8c1929911e33f8/user1-example.com" cannot list resource "replicasets" in API group "apps" in the namespace "kube-system"
            Error from server (Forbidden): statefulsets.apps is forbidden: User "arn:aws:sts::$ACCOUNT_ID:assumed-role/AWSReservedSSO_EKSClusterUser_cd8c1929911e33f8/user1-example.com" cannot list resource "statefulsets" in API group "apps" in the namespace "kube-system"
            Error from server (Forbidden): horizontalpodautoscalers.autoscaling is forbidden: User "arn:aws:sts::$ACCOUNT_ID:assumed-role/AWSReservedSSO_EKSClusterUser_cd8c1929911e33f8/user1-example.com" cannot list resource "horizontalpodautoscalers" in API group "autoscaling" in the namespace "kube-system"
            Error from server (Forbidden): cronjobs.batch is forbidden: User "arn:aws:sts::$ACCOUNT_ID:assumed-role/AWSReservedSSO_EKSClusterUser_cd8c1929911e33f8/user1-example.com" cannot list resource "cronjobs" in API group "batch" in the namespace "kube-system"
            Error from server (Forbidden): jobs.batch is forbidden: User "arn:aws:sts::$ACCOUNT_ID:assumed-role/AWSReservedSSO_EKSClusterUser_cd8c1929911e33f8/user1-example.com" cannot list resource "jobs" in API group "batch" in the namespace "kube-system"
        ```

        > You should only have access on the `default` and `development` Namespaces as the above output sample. You should also be able to list Namespaces.

## Tear down

1. To tear down the environment, run the following commands in order.

    ```sh
    terraform destroy -target="module.eks_blueprints_addons" -target="module.karpenter_addon" -auto-approve
    terraform destroy -target="module.karpenter" -auto-approve
    terraform destroy -target="module.eks" -auto-approve
    ```

2. You'll need to comment back the `kubernetes_manifest` resource in the `vpc.tf`, so Terraform will be able to fully clean up the remaining resources.

    ```sh
    # resource "kubernetes_manifest" "eni_config" {
    #     for_each = zipmap(local.azs, slice(module.vpc.private_subnets, 4, 8))
    #       manifest = {
    #         apiVersion = "crd.k8s.amazonaws.com/v1alpha1"
    #         kind       = "ENIConfig"
    #         metadata = {
    #         name = each.key
    #         }
    #         spec = {
    #             securityGroups = [
    #             module.eks.node_security_group_id,
    #             ]
    #             subnet = each.value
    #         }
    #     }
    # }
    ```

3. Run the final `destroy` command.

    ```sh
    terraform destroy -auto-approve
    ```

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.0 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 5.0 |
| <a name="requirement_helm"></a> [helm](#requirement\_helm) | >= 2.9 |
| <a name="requirement_kubernetes"></a> [kubernetes](#requirement\_kubernetes) | >= 2.20 |
| <a name="requirement_random"></a> [random](#requirement\_random) | >= 3.6.0 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | 5.97.0 |
| <a name="provider_aws.virginia"></a> [aws.virginia](#provider\_aws.virginia) | 5.97.0 |
| <a name="provider_helm"></a> [helm](#provider\_helm) | 2.17.0 |
| <a name="provider_kubernetes"></a> [kubernetes](#provider\_kubernetes) | 2.36.0 |
| <a name="provider_random"></a> [random](#provider\_random) | 3.7.2 |

## Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_developers_team"></a> [developers\_team](#module\_developers\_team) | aws-ia/eks-blueprints-teams/aws | 1.1.0 |
| <a name="module_ebs_kms_key"></a> [ebs\_kms\_key](#module\_ebs\_kms\_key) | terraform-aws-modules/kms/aws | ~> 3.1 |
| <a name="module_efs"></a> [efs](#module\_efs) | terraform-aws-modules/efs/aws | ~> 1.1 |
| <a name="module_eks"></a> [eks](#module\_eks) | terraform-aws-modules/eks/aws | ~> 20.5 |
| <a name="module_eks_blueprints_addons"></a> [eks\_blueprints\_addons](#module\_eks\_blueprints\_addons) | aws-ia/eks-blueprints-addons/aws | ~> 1.15 |
| <a name="module_karpenter"></a> [karpenter](#module\_karpenter) | terraform-aws-modules/eks/aws//modules/karpenter | ~> 20.24 |
| <a name="module_karpenter_addon"></a> [karpenter\_addon](#module\_karpenter\_addon) | aws-ia/eks-blueprints-addon/aws | ~> 1.1 |
| <a name="module_vpc"></a> [vpc](#module\_vpc) | terraform-aws-modules/vpc/aws | ~> 5.0 |

## Resources

| Name | Type |
|------|------|
| [aws_ec2_tag.karpenter_subnets](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ec2_tag) | resource |
| [aws_identitystore_group.developers](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/identitystore_group) | resource |
| [aws_identitystore_group.operators](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/identitystore_group) | resource |
| [aws_identitystore_group_membership.developers](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/identitystore_group_membership) | resource |
| [aws_identitystore_group_membership.operators](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/identitystore_group_membership) | resource |
| [aws_identitystore_user.admin](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/identitystore_user) | resource |
| [aws_identitystore_user.user](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/identitystore_user) | resource |
| [aws_ssoadmin_account_assignment.developer](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssoadmin_account_assignment) | resource |
| [aws_ssoadmin_account_assignment.operators](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssoadmin_account_assignment) | resource |
| [aws_ssoadmin_managed_policy_attachment.admin](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssoadmin_managed_policy_attachment) | resource |
| [aws_ssoadmin_managed_policy_attachment.user](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssoadmin_managed_policy_attachment) | resource |
| [aws_ssoadmin_permission_set.admin](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssoadmin_permission_set) | resource |
| [aws_ssoadmin_permission_set.user](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssoadmin_permission_set) | resource |
| [aws_ssoadmin_permission_set_inline_policy.admin](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssoadmin_permission_set_inline_policy) | resource |
| [aws_ssoadmin_permission_set_inline_policy.user](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssoadmin_permission_set_inline_policy) | resource |
| [helm_release.karpenter_resources](https://registry.terraform.io/providers/hashicorp/helm/latest/docs/resources/release) | resource |
| [kubernetes_annotations.gp2](https://registry.terraform.io/providers/hashicorp/kubernetes/latest/docs/resources/annotations) | resource |
| [kubernetes_manifest.eni_config](https://registry.terraform.io/providers/hashicorp/kubernetes/latest/docs/resources/manifest) | resource |
| [kubernetes_storage_class_v1.efs](https://registry.terraform.io/providers/hashicorp/kubernetes/latest/docs/resources/storage_class_v1) | resource |
| [kubernetes_storage_class_v1.gp3](https://registry.terraform.io/providers/hashicorp/kubernetes/latest/docs/resources/storage_class_v1) | resource |
| [random_pet.name](https://registry.terraform.io/providers/hashicorp/random/latest/docs/resources/pet) | resource |
| [aws_availability_zones.available](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/availability_zones) | data source |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_ecrpublic_authorization_token.token](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ecrpublic_authorization_token) | data source |
| [aws_iam_policy_document.admin](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.user](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_roles.admin](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_roles) | data source |
| [aws_iam_roles.user](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_roles) | data source |
| [aws_ssoadmin_instances.this](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/ssoadmin_instances) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_admin_user_config"></a> [admin\_user\_config](#input\_admin\_user\_config) | Configuration for Platform Admin Users. | <pre>list(object({<br>    family_name = string<br>    given_name  = string<br>    email       = string<br>  }))</pre> | <pre>[<br>  {<br>    "email": "admin@example.com",<br>    "family_name": "Admin",<br>    "given_name": "Platform"<br>  }<br>]</pre> | no |
| <a name="input_cidr_block"></a> [cidr\_block](#input\_cidr\_block) | The CIDR block for the VPC | `string` | `"10.0.0.0/16"` | no |
| <a name="input_cluster_version"></a> [cluster\_version](#input\_cluster\_version) | Amazon EKS Kubernetes version. Defaults to `1.29` | `string` | `"1.32"` | no |
| <a name="input_karpenter_crds"></a> [karpenter\_crds](#input\_karpenter\_crds) | n/a | `list(string)` | <pre>[<br>  "ec2nodeclasses.karpenter.k8s.aws",<br>  "nodepools.karpenter.sh",<br>  "nodeclaims.karpenter.sh"<br>]</pre> | no |
| <a name="input_name_prefix"></a> [name\_prefix](#input\_name\_prefix) | Prefix for the environemnt and Amazon EKS Cluster names | `string` | `"amazon-eks"` | no |
| <a name="input_region"></a> [region](#input\_region) | AWS Region to deploy the environemnt | `string` | `"us-west-2"` | no |
| <a name="input_secondary_cidr_block"></a> [secondary\_cidr\_block](#input\_secondary\_cidr\_block) | The CIDR block for the VPC | `string` | `"100.0.0.0/16"` | no |
| <a name="input_user_config"></a> [user\_config](#input\_user\_config) | Configuration for Developer Users. | <pre>list(object({<br>    family_name = string<br>    given_name  = string<br>    email       = string<br>  }))</pre> | <pre>[<br>  {<br>    "email": "user1@example.com",<br>    "family_name": "User1",<br>    "given_name": "Developer"<br>  },<br>  {<br>    "email": "user2@example.com",<br>    "family_name": "User2",<br>    "given_name": "Developer"<br>  }<br>]</pre> | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_configure_kubectl"></a> [configure\_kubectl](#output\_configure\_kubectl) | Configure kubectl: make sure you're logged in with the correct AWS profile and run the following command to update your kubeconfig. |
| <a name="output_configure_sso_admins"></a> [configure\_sso\_admins](#output\_configure\_sso\_admins) | Example configuration for SSO with provisioned Admin user. |
| <a name="output_configure_sso_users"></a> [configure\_sso\_users](#output\_configure\_sso\_users) | Example configuration for SSO with provisioned read-only User. |
