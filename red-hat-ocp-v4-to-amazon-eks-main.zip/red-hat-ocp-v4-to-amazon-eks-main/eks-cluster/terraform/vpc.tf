################################################################################
# VPC
################################################################################
locals {
  azs = slice(data.aws_availability_zones.available.names, 0, 4)
}

module "vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "~> 5.0"

  name                  = local.name
  cidr                  = var.cidr_block
  secondary_cidr_blocks = [var.secondary_cidr_block] # can add up to 5 total CIDR blocks

  azs             = local.azs
  private_subnets = concat([for k, v in local.azs : cidrsubnet(var.cidr_block, 4, k)], [for k, v in local.azs : cidrsubnet(var.secondary_cidr_block, 2, k)])
  public_subnets  = [for k, v in local.azs : cidrsubnet(var.cidr_block, 4, k + 8)]

  enable_nat_gateway = true
  single_nat_gateway = true

  public_subnet_tags = {
    "kubernetes.io/role/elb" = 1
  }

  private_subnet_tags = {
    "kubernetes.io/role/internal-elb" = 1
    # Tags subnets for Karpenter auto-discovery
    "karpenter.sh/discovery" = local.name
    "kubernetes.io/role/cni" = "1"

  }

  tags = local.tags
}

resource "kubernetes_manifest" "eni_config" {
  for_each = zipmap(local.azs, slice(module.vpc.private_subnets, 4, 8))

  manifest = {
    apiVersion = "crd.k8s.amazonaws.com/v1alpha1"
    kind       = "ENIConfig"
    metadata = {
      name = each.key
    }
    spec = {
      securityGroups = [
        module.eks.node_security_group_id,
      ]
      subnet = each.value
    }
  }
}

resource "aws_ec2_tag" "karpenter_subnets" {
  for_each = zipmap(local.azs, slice(module.vpc.private_subnets, 0, 4))

  resource_id = each.value
  key         = "karpenter.sh/discovery"
  value       = local.name
}
