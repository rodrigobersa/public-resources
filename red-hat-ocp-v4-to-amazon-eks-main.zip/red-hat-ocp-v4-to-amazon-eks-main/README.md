# Red Hat OpenShift to Amazon EKS migration pattern

## Summary

This pattern provides guidance for migrating from Red Hat OpenShift Container Platform (OCP) to Amazon Elastic Kubernetes Service (Amazon EKS).

You can follow the steps in this pattern to move the all existing resources in you running OCP environment one-by-one, and you can also choose the ones you want to migrate, or believe that makes more sense to be in the new environment. During the process we will provide you automation scripts and explanation about the objects we are moving, the ones we are not, and why you don't need to bring these objects.

Also, we're providing Infrastructure-as-Code (IaC) scripts if you need to provision an Amazon EKS Cluster, either for a migration testing or to actually migrate your environment. Just be aware the IaC may not cover all the requirements you need, and it's maybe required to adjust the deployment.

You can use this pattern whenever you want to migrate from an OCP to Amazon EKS, with the objective of:

* Avoid license lock-in;
* Enjoy using an OpenSource Community product with Enterprise Support;
* Freedom to choose any Kubernetes compatible OS flavor;
* Make use of AWS Managed Services benefits;
* Native integration with other AWS Services;
* No concerns about managing infrastructure;
* Avoid using proprietary objects that are not available for the Kubernetes community or CNCF.

## AWS Services

* [Amazon ECR](https://aws.amazon.com/ecr/) - is a fully managed container registry that makes it easy to store, manage, share, and deploy your container images and artifacts anywhere. Amazon ECR eliminates the need to operate your own container repositories or worry about scaling the underlying infrastructure.
* [Amazon EFS](https://docs.aws.amazon.com/efs/latest/ug/whatisefs.html) - manages file storage in the AWS Cloud. In this pattern, it provides a simple, scalable, fully managed, and shared file system for use with Amazon EKS.
* [Amazon EKS](https://docs.aws.amazon.com/eks/latest/userguide/what-is-eks.html) - helps you run Kubernetes on AWS without needing to install or operate your own clusters.
* [Amazon VPC](https://aws.amazon.com/vpc) - is a service that lets you launch AWS resources in a logically isolated virtual network that you define, with a complete control over your virtual networking environment.
* [Amazon ELB](https://aws.amazon.com/elasticloadbalancing/) - Elastic Load Balancing (ELB) automatically distributes incoming application traffic across multiple targets, such as containers, and it can handle the varying load of your application traffic in a single Availability Zone or across multiple Availability Zones.
* [Route 53](https://aws.amazon.com/route53/) - is a highly available and scalable cloud [Domain Name System (DNS)](https://aws.amazon.com/route53/what-is-dns/) web service.
* Validate if any service is missing here.

## Prerequisites and limitations

### Prerequisites

* An active AWS account
* An AdministratorAccess role attached to the bastion host (if you don't have one we can provide guidance on how to create)
* An existing Red Hat OpenShift Container Platform (OCP) cluster version 4, with a valid subscription
* Cluster administration permissions at the existing Red Hat OCP

## Limitations

* This pattern uses the Amazon EC2 as the compute choice. We'll not cover Fargate configuration.
* This pattern provides an epic to cover migration of images that exist in the OpenShift Internal Registry. If you use an external registry, you should configure Amazon EKS to access it.
* The IaC that creates the Amazon EKS cluster does not reference any Amazon EKS version by default, please provide a supported version of your choice as a variable. [Check here for the supported versions](https://docs.aws.amazon.com/eks/latest/userguide/kubernetes-versions.html#kubernetes-release-calendar)
* The code provided with this pattern can run on any machines that support `bash` interpreter.
* This pattern does not cover Data/Storage migration. We'll cover the migration of Kubernetes resources like `PersistentVolumeClaims` (PVC), but not the data on it.
* This pattern does not cover Istio/ServiceMesh configuration.

## Tools and versions

* [AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/cli-chap-welcome.html) – AWS Command Line Interface (AWS CLI) is an open-source tool that you can use to interact with AWS services from the command line.
* [eksctl](https://docs.aws.amazon.com/eks/latest/userguide/getting-started-eksctl.html) – eksctl is a command-line utility for creating and managing Kubernetes clusters on Amazon EKS.
* [kubectl](https://docs.aws.amazon.com/eks/latest/userguide/install-kubectl.html) – kubectl is a command-line utility for communicating with the cluster API server.
* [jq](https://stedolan.github.io/jq/) – jq is a command-line tool for parsing JSON.
* [yq](https://kislyuk.github.io/yq/) - yq is a command-line tool for parsing YAML.
* [helm](https://helm.sh/) - Helm is a package manager for Kubernetes Cluster

### Product versions

* AWS Command Line Interface (AWS CLI) version 2 or later
* eksctl version 0.200.0 or later
* jq version 1.6 or later
* yq version 4.30.0 or later
* kubectl version 1.24 or later
* Red Hat OpenShift Container Platform v4

## Architecture

### Source technology stack

The source architecture usually includes the following services and components, in this pattern emulating that it is deployed in AWS, and follows [Red Hat OpenShift Reference Architecture Implementation Guides](https://www.openshift.com/blog/openshift-container-platform-reference-architecture-implementation-guides):

* An Amazon VPC that spans three Availability Zones, with one public and one private subnet per Availability Zone.
* An internet gateway to provide internet access to each subnet.
* Three NAT gateways, one in each public subnet, providing access to the Internet from the private subnets.
* In the private subnets:
  * An NLB for the master API that is Internet addressable.
  * An NLB for Machine Config server, not addressable from the Internet.
  * An ELB Classic for infrastructure router service that is used to route a Red Hat OpenShift Container Platform service to it’s pods
  * A Bastion instance.
  * Three master instances.
  * Three infrastructure instances.
  * Three application instances.

![SourceArchitecture](static/images/ocp4.png "SourceArchitecture")

### Target technology stack

The target architecture should include, but not limit, the following services and components, and follows [AWS Well-Architected Framework](https://aws.amazon.com/architecture/well-architected/) best practices:

* An Amazon VPC with 3 (three) private subnets and 3 (three) public subnets, in different Availability Zones (AZ), provide redundancy for your workloads and load balancers.
* Route 53 hosted zone for application hostnames resolution.
* Amazon EKS, for running the Kubernetes workloads and components migrated from Red Hat OCP.
* Elastic Load Balancing (ELB), for load balancing traffic to your workloads. Whenever you create a Kubernetes Ingress, an AWS Application Load Balancer is provisioned that load balances application traffic. Whenever you create a Kubernetes Service of type LoadBalancer, an AWS Network Load Balancer (NLB) or Classic Load Balancer (CLB) is provisioned to balance network traffic load.
* Amazon EC2 as the compute choice for running your workloads.
* Amazon Elastic Container Registry (Amazon ECR), for storing and managing your container images.
* Amazon EBS or Amazon EFS to be used as a shared file system, for being used by workloads that need persistent storage.
* An Amazon EFS mount target for each private subnet, providing redundancy per Availability Zone within the virtual private cloud (VPC) of the cluster.

![TargetArchitecture](static/images/eks.png "TargetArchitecture")

## Related resources

### References

* [Application load balancing on Amazon EKS](https://docs.aws.amazon.com/eks/latest/userguide/alb-ingress.html) (AWS documentation)
* [Cluster Autoscaler](https://docs.aws.amazon.com/eks/latest/userguide/cluster-autoscaler.html) (AWS documentation)
* [EC2 or AWS Fargate?](https://containersonaws.com/introduction/ec2-or-aws-fargate/) (blog)
* [Exposing the registry](https://docs.openshift.com/container-platform/4.3/registry/securing-exposing-registry.html) (Red Hat documentation)
* [Network load balancing on Amazon EKS](https://docs.aws.amazon.com/eks/latest/userguide/load-balancing.html) (AWS documentation)
* [OpenShift Container Platform Reference Architecture Implementation Guides](https://www.openshift.com/blog/openshift-container-platform-reference-architecture-implementation-guides) (Red Hat documentation)
* [Pull an Image from a Private Registry](https://kubernetes.io/docs/tasks/configure-pod-container/pull-image-private-registry/) (Kubernetes documentation)
* [Configuring Amazon EFS CSI for Amazon EKS](https://docs.aws.amazon.com/eks/latest/userguide/efs-csi.html) (AWS documentation)

### Tutorial and examples

* [Cluster Autoscaler on AWS](https://github.com/kubernetes/autoscaler/blob/master/cluster-autoscaler/cloudprovider/aws/README.md) (GitHub repo)
* [Red Hat OpenShift on AWS](http://https://aws.amazon.com/quickstart/architecture/openshift/) (quick start)

### Required tools

* [Installing the AWS CLI version 2](https://docs.aws.amazon.com/cli/latest/userguide/install-cliv2.html)
* [Installing eksctl](https://docs.aws.amazon.com/eks/latest/userguide/eksctl.html)
* [Installing kubectl](https://docs.aws.amazon.com/eks/latest/userguide/install-kubectl.html)
* [Installing jq](https://stedolan.github.io/jq/download/)
* [Installing yq](https://kislyuk.github.io/yq/#installation)
* [Installing helm](https://helm.sh/docs/intro/install/) (or if you prefer, you can follow this [AWS Documentation for Using Helm with Amazon EKS](https://docs.aws.amazon.com/eks/latest/userguide/helm.html))

#### Required tools installation

Installing the AWS CLI version 2

```sh
sudo curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install
```

### Installing eksctl

```sh
sudo curl --silent --location \ 
"https://github.com/weaveworks/eksctl/releases/latest/download/eksctl_$(uname -s)_amd64.tar.gz" | tar xz -C /tmp
sudo mv -v /tmp/eksctl /usr/local/bin

eksctl completion bash >> ~/.bash_completion . /etc/profile.d/bash_completion.sh . ~/.bash_completion
```

### Installing kubectl

```sh
sudo curl --silent --location -o /usr/local/bin/kubectl \
https://amazon-eks.s3.us-west-2.amazonaws.com/1.18.9/2020-11-02/bin/darwin/amd64/kubectl

kubectl completion bash >> ~/.bash_completion . /etc/profile.d/bash_completion.sh . ~/.bash_completion
```

### Installing jq

YUM Based (CentOS/Fedora/RedHat/AL)

```sh
sudo yum install -y jq
```

APT Based (Debian/Ubuntu)

```sh
sudo apt-get install -y jq
```

### Installing yq

YUM Based (CentOS/Fedora/RedHat/AL)

```sh
sudo yum install -y python3-pip
pip3 install yq
```

APT Based (Debian/Ubuntu)

```sh
sudo apt-get install -y python3-pip
pip3 install yq
```

### Installing Helm

```sh
curl https://raw.githubusercontent.com/helm/helm/master/scripts/get-helm-3 > get_helm.sh
chmod 700 get_helm.sh
./get_helm.sh
```

## Additional information

The scripts that automate the epics and stories for this pattern are included in the `/scripts` directory and described in the following sections.

### Epic 01 - Migrate Images

Migrate container images from Red Hat OpenShift Internal Registry to Amazon ECR Repositories: This epic covers the steps to expose the OpenShift internal registry, identify all images, create corresponding Amazon ECR repositories, and migrate the images.

### Epic 02 - Namespaces and Namespaced resources (PDBs, NetPols, Quotas, LimitRanges)

Create Namespace, LimitRange, ResourceQuota, NetworkPolicy, and PodDisruptionBudget objects: This epic focuses on migrating namespace, resource quota, network policies, and pod disruption budget objects from OpenShift to the new Amazon EKS cluster.

### Epic 03 - Authorization (Roles and ClusterRoles)

Create Role, RoleBinding, ClusterRole, and ClusterRoleBinding objects: This epic covers the migration of role-based access control objects like roles, role bindings, cluster roles, and cluster role bindings.

### Epic 04 - ConfigMaps, Secrets and SAs

Create ConfigMap, ServiceAccount and Secret objects: This epic addresses the migration of configuration maps, service accounts, and secrets from OpenShift to Amazon EKS.

### Epic 05 - PVCs

Create PersistentVolumeClaim objects: This epic focuses on migrating persistent volume claims from OpenShift to the new Amazon EKS cluster.

### Epic 06 - Cronjobs

Create CronJob objects: This epic handles the migration of cron job objects from OpenShift.

### Epic 07 - Deployments, DeploymentConfigs and HPAs

Create Deployment, DeploymentConfig and Horizontal Pod Autoscaler objects: This epic covers the migration of deployment and deployment config object, as well as handles the migration of horizontal pod autoscaler objects.

### Epic 09 - DaemonSets and StatefulSets

Create DaemonSet, and StatefulSet objects: This epic addresses the migration of daemon set and stateful set objects.

### Epic 10 - Services and Ingress

Create Service and Ingress objects: This epic focuses on migrating service objects, including the conversion of OpenShift route objects to Ingress objects in Amazon EKS.
