#!/bin/bash

SOURCE_DIR=`dirname "$0"`
source $SOURCE_DIR/../common/common.sh

# Login on OCP
login_ocp

for PROJECT in $OCP_PROJECTS
do
  # HPA
  mkdir -p $WORKING_DIR/$PROJECT/hpa
  echo "Exporting Horizontal Pod Autoscaler objects on project: $PROJECT"
  echo "Directory: $WORKING_DIR/$PROJECT/hpa"

  for HPA in $(oc get hpa --no-headers -n $PROJECT | awk '{print $1}') 
  do
    oc get hpa $HPA -n $PROJECT -o yaml | \
      yq eval 'del(.status, .metadata.creationTimestamp, .metadata.managedFields, .metadata.resourceVersion, .metadata.selfLink, .metadata.uid)' - | \
      sed -e 's/.openshift.io//g' | \
      sed -e 's/DeploymentConfig/Deployment/g' | \
      sed -e 's/ReplicationController/ReplicaSet/g' \
      > $WORKING_DIR/$PROJECT/hpa/$HPA.yaml
  done
done

# Login on EKS
login_eks

# Importing HPA objects
import_objects "HPA"
