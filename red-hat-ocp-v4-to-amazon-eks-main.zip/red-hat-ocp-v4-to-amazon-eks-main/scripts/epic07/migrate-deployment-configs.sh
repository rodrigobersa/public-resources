#!/bin/bash

SOURCE_DIR=`dirname "$0"`
source $SOURCE_DIR/../common/common.sh

if [ -z "${INTERNAL_REGISTRY_ROUTE// }" ]; then
  echo "If you are migrating to Amazon ECR, please, specify the internal registry route (e.g. image-registry.openshift-image-registry.svc:5000): "
  read INTERNAL_REGISTRY_ROUTE
fi

# Login on OCP
login_ocp

for PROJECT in $OCP_PROJECTS
do
  if [ -z "${NODE_LABEL// }" ]; then
    echo "If you want to deploy project $PROJECT into a specific Node Group, please specify the respective tag. (e.g. type=cpu, app=docker, foo=bar): "
    read NODE_LABEL
  fi

  NODE_LABEL_KEY=$(echo $NODE_LABEL | cut -d= -f1)
  NODE_LABEL_VALUE=$(echo $NODE_LABEL | cut -d= -f2)

  # DeploymentConfig
  mkdir -p $WORKING_DIR/$PROJECT/deployment
  echo "Exporting DeploymentConfig objects on project: $PROJECT"
  echo "Directory: $WORKING_DIR/$PROJECT/deployment"

  for DEPLOY_CONFIG in $(oc get dc --no-headers -n $PROJECT | awk '{print $1}')
  do
    if [ -z "${INTERNAL_REGISTRY_ROUTE// }" ]
    then
      if [ -z "${NODE_LABEL// }" ]
      then
        oc get dc -n $PROJECT -o yaml $DEPLOY_CONFIG | \
          yq eval 'del(.metadata.resourceVersion, .metadata.uid, .metadata.annotations, .metadata.creationTimestamp, .metadata.selfLink, .metadata.managedFields, .metadata.generation,  .status, .spec.triggers, .spec.test, .spec.strategy.activeDeadlineSeconds, .spec.strategy.recreateParams, .spec.strategy.rollingParams.intervalSeconds, .spec.strategy.rollingParams.timeoutSeconds, .spec.strategy.rollingParams.updatePeriodSeconds, .spec.strategy.resources, .spec.template.metadata.annotations."openshift.io/generated-by") | select(fileIndex == 0) * {"spec": {"selector": {"matchLabels": .spec.selector}}} | del(.spec.selector."deployment-config.name")' - | \
          sed -e "s/DeploymentConfig/Deployment/g" | \
          sed -e "s/.openshift.io//g" | \
          sed -e "s/app:/name:/g" | \
          sed -e "s/Params/Update/g" | \
          sed -e "s/Rolling/RollingUpdate/g" | \
          sed "s/@sha256.*//g" \
          > $WORKING_DIR/$PROJECT/deployment/$DEPLOY_CONFIG.yaml
      else
        oc get dc -n $PROJECT -o yaml $DEPLOY_CONFIG | \
          yq eval 'del(.metadata.resourceVersion, .metadata.uid, .metadata.annotations, .metadata.creationTimestamp, .metadata.selfLink, .metadata.managedFields, .metadata.generation,  .status, .spec.triggers, .spec.test, .spec.strategy.activeDeadlineSeconds, .spec.strategy.recreateParams, .spec.strategy.rollingParams.intervalSeconds, .spec.strategy.rollingParams.timeoutSeconds, .spec.strategy.rollingParams.updatePeriodSeconds, .spec.strategy.resources, .spec.template.metadata.annotations."openshift.io/generated-by") | select(fileIndex == 0) * {"spec": {"selector": {"matchLabels": .spec.selector}}} | select(fileIndex == 0) * {"spec": {"template": {"spec": {"nodeSelector": { "KEY": "VALUE" }}}}} | del(.spec.selector."deployment-config.name")' - | \
          sed -e "s/DeploymentConfig/Deployment/g" | \
          sed -e "s/.openshift.io//g" | \
          sed -e "s/app:/name:/g" | \
          sed -e "s/Rolling/RollingUpdate/g" | \
          sed -e "s/KEY/$NODE_LABEL_KEY/g" | sed -e "s/VALUE/$NODE_LABEL_VALUE/g" | \
          sed "s/@sha256.*//g" \
          > $WORKING_DIR/$PROJECT/deployment/$DEPLOY_CONFIG.yaml
      fi
    else
      if [ -z "${NODE_LABEL// }" ]
      then
        oc get dc -n $PROJECT -o yaml $DEPLOY_CONFIG | \
          yq eval 'del(.metadata.resourceVersion, .metadata.uid, .metadata.annotations, .metadata.creationTimestamp, .metadata.selfLink, .metadata.managedFields, .metadata.generation,  .status, .spec.triggers, .spec.test, .spec.strategy.activeDeadlineSeconds, .spec.strategy.recreateParams, .spec.strategy.resources, .spec.template.metadata.annotations."openshift.io/generated-by") | select(fileIndex == 0) * {"spec": {"selector": {"matchLabels": .spec.selector}}} | del(.spec.selector.name)' - | \
          sed -e "s/DeploymentConfig/Deployment/g" | \
          sed -e "s/.openshift.io//g" | \
          sed "s/@sha256.*//g" | \
          sed "s/$INTERNAL_REGISTRY_ROUTE/$ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/g" \
          > $WORKING_DIR/$PROJECT/deployment/$DEPLOY_CONFIG.yaml
      else 
        oc get dc -n $PROJECT -o yaml $DEPLOY_CONFIG | \
          yq eval 'del(.metadata.resourceVersion, .metadata.uid, .metadata.annotations, .metadata.creationTimestamp, .metadata.selfLink, .metadata.managedFields, .metadata.generation,  .status, .spec.triggers, .spec.test, .spec.strategy.activeDeadlineSeconds, .spec.strategy.recreateParams, .spec.strategy.resources, .spec.template.metadata.annotations."openshift.io/generated-by") | select(fileIndex == 0) * {"spec": {"selector": {"matchLabels": .spec.selector}}} | select(fileIndex == 0) * {"spec": {"template": {"spec": {"nodeSelector": { "KEY": "VALUE" }}}}} | del(.spec.selector.name)' - | \
          sed -e "s/DeploymentConfig/Deployment/g" | \
          sed -e "s/.openshift.io//g" | \
          sed -e "s/KEY/$NODE_LABEL_KEY/g" | sed -e "s/VALUE/$NODE_LABEL_VALUE/g" | \
          sed "s/@sha256.*//g" | \
          sed "s/$INTERNAL_REGISTRY_ROUTE/$ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/g" \
          > $WORKING_DIR/$PROJECT/deployment/$DEPLOY_CONFIG.yaml
      fi
    fi
  done
done

# Login on EKS
login_eks

# Importing Deployment objects
import_objects "Deployment"
