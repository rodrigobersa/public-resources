#!/bin/bash

SOURCE_DIR=`dirname "$0"`
source $SOURCE_DIR/../common/common.sh

if [ -z "${CLUSTER_ROLE// }" ]; then
    echo "Please type the name of the ClusterRole, you want to migrate to the EKS Cluster: "
    read CLUSTER_ROLE
fi
if [ -z "${CLUSTER_ROLE_BINDING// }" ]; then
    echo "Please type the name of the ClusterRoleBinding, you want to migrate to the EKS Cluster: "
    read CLUSTER_ROLE_BINDING
fi

# Login on OCP
login_ocp

# ClusterRole
mkdir -p $WORKING_DIR/cluster/clusterrole
echo "Exporting ClusterRole object: $CLUSTER_ROLE"
echo "Directory: $WORKING_DIR/cluster/clusterrole"

oc get clusterroles $CLUSTER_ROLE -o yaml | \
  yq eval 'del(.metadata.resourceVersion, .metadata.uid, .metadata.creationTimestamp, .metadata.selfLink)' - | \
  sed -e "s/authorization.openshift.io/rbac.authorization.k8s.io/g" | \
  sed -e 's/apps.openshift.io/""/g' > $WORKING_DIR/cluster/clusterrole/$CLUSTER_ROLE.yaml

# ClusterRoleBinding
mkdir -p $WORKING_DIR/cluster/clusterrolebinding
echo "Exporting Cluster RoleBindings object: $CLUSTER_ROLE_BINDING"
echo "Directory: $WORKING_DIR/cluster/clusterrolebinding"

oc get clusterrolebindings $CLUSTER_ROLE_BINDING -o yaml | \
  yq eval 'del(.metadata.resourceVersion, .metadata.uid, .metadata.namespace, .metadata.creationTimestamp, .metadata.selfLink, .userNames) | select(fileIndex == 0) * {"roleRef": {"kind": "ClusterRole"}} | select(fileIndex == 0) * {"roleRef": {"apiGroup": "rbac.authorization.k8s.io"}}' - | \
  sed -e "s/authorization.openshift.io/rbac.authorization.k8s.io/g" > $WORKING_DIR/cluster/clusterrolebinding/$CLUSTER_ROLE_BINDING.yaml

# Login on EKS
login_eks

# Importing ClusterRole objects
import_objects "ClusterRole"

# Importing ClusterRoleBinding objects
import_objects "ClusterRoleBinding"