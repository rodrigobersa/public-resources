#!/bin/bash

SOURCE_DIR=`dirname "$0"`
source $SOURCE_DIR/../common/common.sh

# Login on OCP
login_ocp

for PROJECT in $OCP_PROJECTS
do
  # Role
  mkdir -p $WORKING_DIR/$PROJECT/role
  echo "Exporting Role objects on project: $PROJECT"
  echo "Directory: $WORKING_DIR/$PROJECT/role"

  for ROLE in $(oc get role --no-headers -n $PROJECT | awk '{print $1}')
  do
    oc get role $ROLE -n $PROJECT -o yaml | \
      yq eval 'del(.metadata.resourceVersion, .metadata.uid, .metadata.annotations, .metadata.creationTimestamp, .metadata.selfLink, .metadata.managedFields)' - \
      > $WORKING_DIR/$PROJECT/role/role-$ROLE.yaml
  done

  # RoleBinding
  mkdir -p $WORKING_DIR/$PROJECT/rolebinding
  echo "Exporting RoleBinding objects on project: $PROJECT"
  echo "Directory: $WORKING_DIR/$PROJECT/rolebinding"

  for ROLE_BINDING in $(oc get rolebinding --no-headers -n $PROJECT | awk '{print $1}')
  do
    if [[ $ROLE_BINDING != "admin" ]] && [[ $ROLE_BINDING != system:* ]]
    then
      oc get rolebinding $ROLE_BINDING -n $PROJECT -o yaml | \
        yq eval 'del(.metadata.resourceVersion, .metadata.uid, .metadata.annotations, .metadata.creationTimestamp, .metadata.selfLink, .metadata.managedFields)' - \
        > $WORKING_DIR/$PROJECT/rolebinding/rolebinding-$ROLE_BINDING.yaml
    fi
  done
done

# Login on EKS
login_eks

# Importing Role objects
import_objects "Role"

# Importing RoleBinding objects
import_objects "RoleBinding"