#!/bin/bash

SOURCE_DIR=`dirname "$0"`
source $SOURCE_DIR/../common/common.sh

# Login on OCP
login_ocp

for PROJECT in $OCP_PROJECTS
do
  # ConfigMap
  mkdir -p $WORKING_DIR/$PROJECT/configmap
  echo "Exporting ConfigMap objects on project: $PROJECT"
  echo "Directory: $WORKING_DIR/$PROJECT/configmap"
  for CONFIG_MAP in $(oc get configmap --no-headers -n $PROJECT | awk '{print $1}')
  do
    if [[ $CONFIG_MAP != kube-* ]]
    then
      oc get configmap $CONFIG_MAP -n $PROJECT -o yaml | \
        yq eval 'del(.metadata.resourceVersion, .metadata.uid, .metadata.annotations, .metadata.creationTimestamp, .metadata.selfLink, .metadata.managedFields)' - \
        > $WORKING_DIR/$PROJECT/configmap/configmap-$CONFIG_MAP.yaml
    fi
  done
done

# Login on EKS
login_eks

# Importing ConfigMap objects
import_objects "ConfigMap"