#!/bin/bash

SOURCE_DIR=`dirname "$0"`
source $SOURCE_DIR/../common/common.sh

# Login on OCP
login_ocp

for PROJECT in $OCP_PROJECTS
do
  # Secret
  mkdir -p $WORKING_DIR/$PROJECT/secret
  echo "Exporting Secret objects on project: $PROJECT"
  echo "Directory: $WORKING_DIR/$PROJECT/secret"

  for SECRET in $(oc get secret --no-headers -n $PROJECT | awk '{print $1}')
  do
    if [[ $SECRET != builder-* ]] && [[ $SECRET != default-* ]] && [[ $SECRET != deployer-* ]] && \
        [[ $SECRET != *-dockercfg-* ]] && [[ $SECRET != *-token-* ]]
    then
      oc get secret $SECRET -n $PROJECT -o yaml | \
        yq eval 'del(.metadata.resourceVersion, .metadata.uid, .metadata.annotations, .metadata.creationTimestamp, .metadata.selfLink, .metadata.managedFields)' - \
        > $WORKING_DIR/$PROJECT/secret/secret-$SECRET.yaml
    fi
  done
done

# Login on EKS
login_eks

# Importing Secret objects
import_objects "Secret"