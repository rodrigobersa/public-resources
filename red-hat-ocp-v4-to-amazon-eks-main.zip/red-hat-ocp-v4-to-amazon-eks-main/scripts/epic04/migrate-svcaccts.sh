#!/bin/bash

SOURCE_DIR=`dirname "$0"`
source $SOURCE_DIR/../common/common.sh

# Login on OCP
login_ocp

for PROJECT in $OCP_PROJECTS
do
  # ServiceAccount
  mkdir -p $WORKING_DIR/$PROJECT/serviceaccount
  echo "Exporting ServiceAccount objects on project: $PROJECT"
  echo "Directory: $WORKING_DIR/$PROJECT/serviceaccount"

  for SERVICE_ACCOUNT in $(oc get serviceaccount --no-headers -n $PROJECT | awk '{print $1}')
  do
    if [[ $SERVICE_ACCOUNT != "builder" ]] && [[ $SERVICE_ACCOUNT != "default" ]] && [[ $SERVICE_ACCOUNT != "deployer" ]]
    then
      oc get serviceaccount $SERVICE_ACCOUNT -n $PROJECT -o yaml | \
        yq eval 'del(.metadata.resourceVersion, .metadata.uid, .metadata.annotations, .metadata.creationTimestamp, .metadata.selfLink, .metadata.managedFields, .secrets, .imagePullSecrets)' - \
        > $WORKING_DIR/$PROJECT/serviceaccount/serviceaccount-$SERVICE_ACCOUNT.yaml
    fi
  done
done

# Login on EKS
login_eks

# Importing ServiceAccount objects
import_objects "ServiceAccount"