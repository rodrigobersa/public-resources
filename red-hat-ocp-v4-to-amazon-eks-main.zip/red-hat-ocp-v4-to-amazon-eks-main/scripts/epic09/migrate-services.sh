#!/bin/bash

SOURCE_DIR=`dirname "$0"`
source $SOURCE_DIR/../common/common.sh

if [ -z "${DOMAIN_SUFFIX// }" ]; then
  echo "If you want to migrate your DNS Zone to an Amazon Route53, please create your Hosted Zone and inform the Hosted Zone Domain Suffix. (e.g. example.com. ): "
  read DOMAIN_SUFFIX
fi

# Login on OCP
login_ocp

for PROJECT in $OCP_PROJECTS
do
  # Service
  mkdir -p $WORKING_DIR/$PROJECT/service
  echo "Exporting Service objects on project: $PROJECT"
  echo "Directory: $WORKING_DIR/$PROJECT/service"

  for SVC in $(oc get svc --no-headers -n $PROJECT | awk '{print $1}')
  do
    SVC_TYPE_CUR=$(oc get svc -n $PROJECT $SVC --no-headers | awk '{print $2}')
    SVC_TYPE_NEW=$SVC_TYPE_CUR

    EXIST_ROUTE=$(oc get route -n $PROJECT --field-selector spec.to.name=$SVC)
    if [ ! -z "${EXIST_ROUTE// }" ]; then
      SVC_TYPE_NEW="LoadBalancer"
      ROUTE=$(oc get route -n $PROJECT --field-selector spec.to.name=$SVC --no-headers | awk '{print$2}')
      mkdir -p $WORKING_DIR/$PROJECT/route
      echo $ROUTE > $WORKING_DIR/$PROJECT/route/$SVC.yaml
    fi

    oc get svc -n $PROJECT -o yaml $SVC | \
      yq eval 'del(.metadata.annotations."openshift.io/generated-by", .metadata.annotations."service.alpha.openshift.io/dependencies", .metadata.creationTimestamp, .metadata.labels.template, .metadata.managedFields, .metadata.namespace, .metadata.resourceVersion, .metadata.uid, .metadata.selfLink, .spec.clusterIP, .spec.clusterIPs, .spec.selector.deploymentconfig, .status)' - | \
      sed -e "s/app:/name:/g" | \
      sed -e "s/$SVC_TYPE_CUR/$SVC_TYPE_NEW/g" \
      > $WORKING_DIR/$PROJECT/service/$SVC.yaml 
  done
done

# Login on EKS
login_eks

# Importing Service objects
import_objects "Service"


# Importing Route objects
  if [ "${DOMAIN_SUFFIX// }" ]
    then
      for SVC in $(ls $WORKING_DIR/$PROJECT/route/ | cut -d. -f1) 
        do 
          echo "Creating Route for $SVC Service on Amazon Route53..."
          ALIAS=$(kubectl get svc -n $PROJECT $SVC --no-headers | awk '!/none/ {print $4}')
          ROUTE=$(cat /$WORKING_DIR/$PROJECT/route/$SVC.yaml | cut -d. -f1)
          ZONE_ID=$(aws route53 list-hosted-zones --query "HostedZones[?Name=='$DOMAIN_SUFFIX'].Id" --output text | cut -d/ -f3)

aws route53 change-resource-record-sets --hosted-zone-id $ZONE_ID --change-batch \
'{ "Comment": "Route for '"$SVC"'", "Changes": [ { "Action": "CREATE", "ResourceRecordSet": { "Name": "'"$ROUTE"'.'"$DOMAIN_SUFFIX"'", "Type": "CNAME", "TTL": 300, "ResourceRecords": [ { "Value": "'"$ALIAS"'" } ] } } ] }'

        done
  fi
