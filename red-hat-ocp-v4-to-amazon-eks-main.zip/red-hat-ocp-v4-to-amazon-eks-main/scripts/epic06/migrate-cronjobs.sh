#!/bin/bash

SOURCE_DIR=`dirname "$0"`
source $SOURCE_DIR/../common/common.sh

# Login on OCP
login_ocp

for PROJECT in $OCP_PROJECTS
do
  if [ -z "${NODE_LABEL// }" ]; then
    echo "If you want to deploy project $PROJECT into a specific Node Group, please specify the respective tag. (e.g. type=cpu, app=docker, foo=bar): "
    read NODE_LABEL
  fi

  NODE_LABEL_KEY=$(echo $NODE_LABEL | cut -d= -f1)
  NODE_LABEL_VALUE=$(echo $NODE_LABEL | cut -d= -f2)

  # CronJob
  mkdir -p $WORKING_DIR/$PROJECT/cronjob
  echo "Exporting CronJob objects on Namespace: $PROJECT"
  echo "Directory: $WORKING_DIR/$PROJECT/persistentvolumeclaim"

  for CRON_JOB in $(oc get cronjob --no-headers -n $PROJECT | awk '{print $1}')
  do
    if [ -z "${INTERNAL_REGISTRY_ROUTE// }" ]
    then
      if [ -z "${NODE_LABEL// }" ]
      then
        oc get cronjob $CRON_JOB -n $PROJECT -o yaml | \
          yq eval 'del(.metadata.creationTimestamp, .metadata.managedFields, .metadata.namespace, .metadata.resourceVersion, .metadata.selfLink, .metadata.uid, .spec.metadata.creationTimestamp, .spec.failedJobsHistoryLimit, .spec.successfulJobsHistoryLimit, .spec.jobTemplate.metadata.creationTimestamp, .status)' - \
          > $WORKING_DIR/$PROJECT/cronjob/$CRON_JOB.yaml
      else
        oc get cronjob $CRON_JOB -n $PROJECT -o yaml | \
          yq eval 'del(.metadata.creationTimestamp, .metadata.managedFields, .metadata.namespace, .metadata.resourceVersion, .metadata.selfLink, .metadata.uid, .spec.metadata.creationTimestamp, .spec.failedJobsHistoryLimit, .spec.successfulJobsHistoryLimit, .spec.jobTemplate.metadata.creationTimestamp, .status) | select(fileIndex == 0) * {"spec": {"jobTemplate" {"spec" "{"template": {"spec": {"nodeSelector": { "KEY": "VALUE" }}}}}}}' - \
          sed -e "s/KEY/$NODE_LABEL_KEY/g" | sed -e "s/VALUE/$NODE_LABEL_VALUE/g" \
          > $WORKING_DIR/$PROJECT/cronjob/$CRON_JOB.yaml
      fi
    else
      if [ -z "${NODE_LABEL// }" ]
      then
        oc get cronjob $CRON_JOB -n $PROJECT -o yaml | \
          yq eval 'del(.metadata.creationTimestamp, .metadata.managedFields, .metadata.namespace, .metadata.resourceVersion, .metadata.selfLink, .metadata.uid, .spec.metadata.creationTimestamp, .spec.failedJobsHistoryLimit, .spec.successfulJobsHistoryLimit, .spec.jobTemplate.metadata.creationTimestamp, .status)' - \
          sed "s/$INTERNAL_REGISTRY_ROUTE/$ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/g" > $WORKING_DIR/$PROJECT/cronjob/$CRON_JOB.yaml
      else
        oc get cronjob $CRON_JOB -n $PROJECT -o yaml | \
          yq eval 'del(.metadata.creationTimestamp, .metadata.managedFields, .metadata.namespace, .metadata.resourceVersion, .metadata.selfLink, .metadata.uid, .spec.metadata.creationTimestamp, .spec.failedJobsHistoryLimit, .spec.successfulJobsHistoryLimit, .spec.jobTemplate.metadata.creationTimestamp, .status) | select(fileIndex == 0) * {"spec": {"jobTemplate" {"spec" "{"template": {"spec": {"nodeSelector": { "KEY": "VALUE" }}}}}}}' - \
          sed -e "s/KEY/$NODE_LABEL_KEY/g" | sed -e "s/VALUE/$NODE_LABEL_VALUE/g" \
          sed "s/$INTERNAL_REGISTRY_ROUTE/$ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/g" > $WORKING_DIR/$PROJECT/cronjob/$CRON_JOB.yaml
      fi
    fi
  done
done

# Login on EKS
login_eks

# Importing CronJob objects
import_objects "CronJob"