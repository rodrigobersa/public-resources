#!/bin/bash

SOURCE_DIR=`dirname "$0"`
source $SOURCE_DIR/../common/common.sh

# Login on OCP
login_ocp

for PROJECT in $OCP_PROJECTS
do
  # NetworkPolicy
  mkdir -p $WORKING_DIR/$PROJECT/networkpolicy
  echo "Exporting NetworkPolicy objects on project: $PROJECT"
  echo "Directory: $WORKING_DIR/$PROJECT/networkpolicy"

  for NETWORK_POLICY in $(oc get networkpolicy --no-headers -n $PROJECT | awk '{print $1}')
  do
    oc get networkpolicy $NETWORK_POLICY -n $PROJECT -o yaml  | \
      yq eval 'del(.metadata.creationTimestamp, .metadata.managedFields, .metadata.namespace, .metadata.resourceVersion, .metadata.selfLink, .metadata.generation, .metadata.uid)' - \
      > $WORKING_DIR/$PROJECT/networkpolicy/$NETWORK_POLICY.yaml
  done
done

# Login on EKS
login_eks

# Importing Deployment objects
import_objects "NetworkPolicy"
