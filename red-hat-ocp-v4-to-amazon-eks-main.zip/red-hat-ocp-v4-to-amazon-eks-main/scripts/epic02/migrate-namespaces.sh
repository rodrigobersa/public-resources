#!/bin/bash

SOURCE_DIR=`dirname "$0"`
source $SOURCE_DIR/../common/common.sh

# Login on OCP
login_ocp

for PROJECT in $OCP_PROJECTS
do
  # Namespace
  mkdir -p $WORKING_DIR/$PROJECT/namespace
  echo "Exporting Namespace objects on project: $PROJECT"
  echo "Directory: $WORKING_DIR/$PROJECT/namespace"

  oc get ns $PROJECT -o yaml | \
    yq eval 'del(.metadata.resourceVersion, .metadata.uid, .metadata.annotations, .metadata.creationTimestamp, .metadata.selfLink, .metadata.managedFields, .spec.finalizers, .status)' - \
    > $WORKING_DIR/$PROJECT/namespace/ns-$PROJECT.yaml

  # LimitRange
  mkdir -p $WORKING_DIR/$PROJECT/limitrange
  echo "Exporting LimitRange objects on project: $PROJECT"
  echo "Directory: $WORKING_DIR/$PROJECT/limitrange"

  for LIMIT in $(oc get limitrange --no-headers -n $PROJECT | awk '{print $1}')
  do
    oc get limitrange $LIMIT -n $PROJECT -o yaml | \
      yq eval 'del(.metadata.resourceVersion, .metadata.uid, .metadata.annotations, .metadata.creationTimestamp, .metadata.selfLink, .metadata.managedFields)' - \
      > $WORKING_DIR/$PROJECT/limitrange/lt-$LIMIT.yaml
  done

  # ResourceQuota
  mkdir -p $WORKING_DIR/$PROJECT/resourcequota
  echo "Exporting ResourceQuota objects on project: $PROJECT"
  echo "Directory: $WORKING_DIR/$PROJECT/resourcequota"

  for RESOURCE_QUOTA in $(oc get resourcequota --no-headers -n $PROJECT | awk '{print $1}')
  do
    oc get resourcequota $RESOURCE_QUOTA -n $PROJECT -o yaml | \
      yq eval 'del(.metadata.resourceVersion, .metadata.uid, .metadata.annotations, .metadata.creationTimestamp, .metadata.selfLink, .metadata.managedFields, .status)' - \
      > $WORKING_DIR/$PROJECT/resourcequota/rq-$RESOURCE_QUOTA.yaml
  done
done

# Login on EKS
login_eks

# Importing Namespace objects
import_objects "Namespace"

# Importing LimitRange objects
import_objects "LimitRange"

# Importing ResourceQuota objects
import_objects "ResourceQuota"