#!/bin/bash

SOURCE_DIR=`dirname "$0"`
source $SOURCE_DIR/../common/common.sh

echo "Login on OpenShift Cluster"
login_ocp


for PROJECT in $OCP_PROJECTS
do
  # PodDisruptionBudget
  mkdir -p $WORKING_DIR/$PROJECT/poddisruptionbudget
  echo "Exporting PodDisruptionBudget objects on Namespace: $PROJECT"
  echo "Directory: $WORKING_DIR/$PROJECT/poddisruptionbudget"

  for PDB in $(oc get pdb --no-headers -n $PROJECT | awk '{print $1}')
  do
    oc get pdb $PDB -n $PROJECT -o yaml | \
      yq eval 'del(.metadata.generation, .metadata.creationTimestamp, .metadata.managedFields, .metadata.resourceVersion, .metadata.uid, .metadata.selfLink, .status)' - \
      > $WORKING_DIR/$PROJECT/poddisruptionbudget/$PDB.yaml
  done
done

echo "Login on EKS Cluster"

# Login on EKS
login_eks

# Importing PodDisruptionBudget objects
import_objects "PodDisruptionBudget"
