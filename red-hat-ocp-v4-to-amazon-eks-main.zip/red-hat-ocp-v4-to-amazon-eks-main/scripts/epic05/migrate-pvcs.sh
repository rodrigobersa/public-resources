#!/bin/bash

SOURCE_DIR=`dirname "$0"`
source $SOURCE_DIR/../common/common.sh

if [ -z "${STORAGE_CLASS// }" ]; then
    echo "Please type the name of your destination Storage Class, for automatic provision the PVs according to the exported PVCs: "
    read STORAGE_CLASS
fi

# Login on OCP
login_ocp

for PROJECT in $OCP_PROJECTS
do
  # PersistentVolumeClaim
  mkdir -p $WORKING_DIR/$PROJECT/persistentvolumeclaim
  echo "Exporting PersistentVolumeClaim objects on project: $PROJECT"
  echo "Directory: $WORKING_DIR/$PROJECT/persistentvolumeclaim"

  for PVC in $(oc get pvc --no-headers -n $PROJECT | awk '{print $1}')
  do
    oc get pvc $PVC -n $PROJECT -o yaml | \
      yq eval 'del(.metadata.annotations, .metadata.creationTimestamp, .metadata.selfLink, .metadata.finalizers, .metadata.managedFields, .metadata.resourceVersion, .metadata.uid, .spec.volumeName, .spec.storageClassName, .status) | select(fileIndex == 0) * {"spec": {"storageClassName": "storage_class" }}' - | \
      sed -e "s/storage_class/$STORAGE_CLASS/g" > $WORKING_DIR/$PROJECT/persistentvolumeclaim/$PVC.yaml
  done
done


# Login on EKS
login_eks

# Importing PersistentVolumeClaim objects
import_objects "PersistentVolumeClaim"