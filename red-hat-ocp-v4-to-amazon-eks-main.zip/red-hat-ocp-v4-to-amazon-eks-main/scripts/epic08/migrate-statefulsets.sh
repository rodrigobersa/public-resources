#!/bin/bash

SOURCE_DIR=`dirname "$0"`
source $SOURCE_DIR/../common/common.sh

if [ -z "${INTERNAL_REGISTRY_ROUTE// }" ]; then
  echo "If you are migrating to Amazon ECR, please, specify the internal registry route (e.g. image-registry.openshift-image-registry.svc:5000): "
  read INTERNAL_REGISTRY_ROUTE
fi

# Login on OCP
login_ocp

for PROJECT in $OCP_PROJECTS
do
  if [ -z "${NODE_LABEL// }" ]; then
    echo "If you want to deploy project $PROJECT into a specific Node Group, please specify the respective tag. (e.g. type=cpu, app=docker, foo=bar): "
    read NODE_LABEL
  fi

  NODE_LABEL_KEY=$(echo $NODE_LABEL | cut -d= -f1)
  NODE_LABEL_VALUE=$(echo $NODE_LABEL | cut -d= -f2)

  # StatefulSet
  mkdir -p $WORKING_DIR/$PROJECT/statefulset
  echo "Exporting StatefulSet objects on project: $PROJECT"
  echo "Directory: $WORKING_DIR/$PROJECT/statefulset"

  for STATEFULSET in $(oc get statefulset --no-headers -n $PROJECT | awk '{print $1}')
  do
    if [ -z "${INTERNAL_REGISTRY_ROUTE// }" ]
    then
      if [ -z "${NODE_LABEL// }" ]
      then
        oc get statefulset -n $PROJECT -o yaml  $STATEFULSET | \
          yq eval 'del(.metadata.annotations."openshift.io/generated-by", .metadata.creationTimestamp, .metadata.generation, .metadata.managedFields, .metadata.namespace, .metadata.resourceVersion, .metadata.selfLink, .metadata.uid, .spec.template.metadata.creationTimestamp, .spec.volumeClaimTemplates.[0].metadata.creationTimestamp, .spec.volumeClaimTemplates.[0].status, .status)' - | \
          sed "s/@sha256.*//g" \
          > $WORKING_DIR/$PROJECT/statefulset/$STATEFULSET.yaml
      else
        oc get statefulset -n $PROJECT -o yaml  $STATEFULSET | \
          yq eval 'del(.metadata.annotations."openshift.io/generated-by", .metadata.creationTimestamp, .metadata.generation, .metadata.managedFields, .metadata.namespace, .metadata.resourceVersion, .metadata.selfLink, .metadata.uid, .spec.template.metadata.creationTimestamp, .spec.volumeClaimTemplates.[0].metadata.creationTimestamp, .spec.volumeClaimTemplates.[0].status, .status) | select(fileIndex == 0) * {"spec": {"template": {"spec": {"nodeSelector": { "KEY": "VALUE" }}}}}' - | \
          sed -e "s/KEY/$NODE_LABEL_KEY/g" | sed -e "s/VALUE/$NODE_LABEL_VALUE/g" | \
          sed "s/@sha256.*//g" \
          > $WORKING_DIR/$PROJECT/statefulset/$STATEFULSET.yaml
      fi
    else
      if [ -z "${NODE_LABEL// }" ]
      then
        oc get statefulset -n $PROJECT -o yaml $STATEFULSET | \
          yq eval 'del(.metadata.annotations."openshift.io/generated-by", .metadata.creationTimestamp, .metadata.generation, .metadata.managedFields, .metadata.namespace, .metadata.resourceVersion, .metadata.selfLink, .metadata.uid, .spec.template.metadata.creationTimestamp, .spec.volumeClaimTemplates.[0].metadata.creationTimestamp, .spec.volumeClaimTemplates.[0].status, .status)' - | \
          sed "s/@sha256.*//g" | \
          sed "s/$INTERNAL_REGISTRY_ROUTE/$ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/g" \
          > $WORKING_DIR/$PROJECT/statefulset/$STATEFULSET.yaml
      else
        oc get statefulset -n $PROJECT -o yaml $STATEFULSET | \
          yq eval 'del(.metadata.annotations."openshift.io/generated-by", .metadata.creationTimestamp, .metadata.generation, .metadata.managedFields, .metadata.namespace, .metadata.resourceVersion, .metadata.selfLink, .metadata.uid, .spec.template.metadata.creationTimestamp, .spec.volumeClaimTemplates.[0].metadata.creationTimestamp, .spec.volumeClaimTemplates.[0].status, .status) | select(fileIndex == 0) * {"spec": {"template": {"spec": {"nodeSelector": { "KEY": "VALUE" }}}}}' - | \
          sed -e "s/KEY/$NODE_LABEL_KEY/g" | sed -e "s/VALUE/$NODE_LABEL_VALUE/g" | \
          sed "s/@sha256.*//g" | \
          sed "s/$INTERNAL_REGISTRY_ROUTE/$ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/g" \
          > $WORKING_DIR/$PROJECT/statefulset/$STATEFULSET.yaml
      fi
    fi
  done
done

# Login on EKS
login_eks

# Importing StatefulSet objects
import_objects "StatefulSet"
