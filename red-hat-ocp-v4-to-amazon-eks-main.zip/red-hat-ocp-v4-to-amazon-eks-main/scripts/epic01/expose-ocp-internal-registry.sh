#!/bin/bash
while [ -z "${OCP_DNS_SOA_RECORD_DOMAIN// }" ]
do
  echo "Inform the OpenShift DNS SOA record domain value. This is going to be used to mount the OpenShift image registry's hostname (e.g. image-registry-openshift-image-registry.apps.<OCP_DNS_SOA_RECORD_DOMAIN>): "
  read OCP_DNS_SOA_RECORD_DOMAIN
done

oc project openshift-image-registry
oc create route passthrough --service=image-registry \
  --hostname=image-registry-openshift-image-registry.apps.${OCP_DNS_SOA_RECORD_DOMAIN}