#!/bin/bash
while [ -z "${ACCOUNT_ID// }" ]
do
  echo "Inform the AWS account id in which the Amazon ECR is going to reside: "
  read ACCOUNT_ID
done

while [ -z "${AWS_REGION// }" ]
do
  echo "Inform the region in which the Amazon ECR is going to reside: "
  read AWS_REGION
done

# Login on OCP
login_ocp

OCP_REGISTRY=$(oc get route -n openshift-image-registry --no-headers | awk '{print $2}')
ECR=$ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com

echo "### Login on Exposed OpenShift Registry"

oc whoami -t | docker login -u kubeadmin --password-stdin $OCP_REGISTRY 2> /dev/null

echo "### Pull Docker Image from Projects"

for IMAGE in $(oc get is --no-headers -n $OCP_PROJECTS | awk '{print $2":"$3}' | cut -d/ -f2-) 
do 
  docker pull $OCP_REGISTRY/$IMAGE
done

echo "### Create Amazon ECR Repositories"

for REPO in $(docker images | grep $OCP_PROJECTS | awk '{print $1}')
do 
  for IMAGE in $(echo $REPO | cut -d/ -f2-)
  do 
    aws ecr create-repository --image-scanning-configuration scanOnPush=true --repository-name $IMAGE
  done
done 

echo "### Tag Images for Amazon ECR Repositories"

for REPO in $(docker images | grep $OCP_PROJECTS | awk '{print $1":"$2}')
  do 
    for IMAGE in $(echo $REPO | cut -d/ -f2-)
    do 
      docker tag $REPO $ECR/$IMAGE 
    done
done 

echo "### Login on Amazon ECR"

aws ecr get-login-password | docker login -u AWS --password-stdin $ECR 2> /dev/null

echo "### Push Images to Amazon ECR Repositories"

for ECR_IMAGE in $(docker images | grep $ECR | awk '{print $1":"$2}')
do 
  docker push $ECR_IMAGE
done
