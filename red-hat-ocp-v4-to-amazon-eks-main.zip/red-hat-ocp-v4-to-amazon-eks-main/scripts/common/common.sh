#!/bin/bash

WORKING_DIR=/tmp/ocp4-eks
mkdir -p $WORKING_DIR

declare -p OCP_PROJECTS

while [ -z "${ACCOUNT_ID// }" ]; do
  echo "Inform the AWS account id in which the Amazon ECR is going to reside: "
  read ACCOUNT_ID
done

while [ -z "${AWS_REGION// }" ]; do
  echo "Inform the region in which the Amazon ECR is going to reside: "
  read AWS_REGION
done

while [ -z "${EKS_KUBECONFIG// }" ]; do
  echo "Inform the EKS KUBECONFIG file path (e.g. /opt/eks/kubeconfig): "
  read EKS_KUBECONFIG
done

while [ -z "${OCP_KUBECONFIG// }" ]; do
  echo "Inform the OpenShift KUBECONFIG file path (e.g. /opt/ocp4/auth/kubeconfig): "
  read OCP_KUBECONFIG
done

while [ -z "${OCP_KUBEADMIN_PASSWD// }" ]; do
  echo "Inform the OpenShift KubeAdmin Password file path (e.g. /opt/ocp4/auth/kubeadmin-password): "
  read OCP_KUBEADMIN_PASSWD
done

function login_eks {
  export KUBECONFIG="$EKS_KUBECONFIG"
  echo "========================================================"
  echo "Login on EKS Cluster ($KUBECONFIG)..."
}

function login_ocp {
  export KUBECONFIG="$OCP_KUBECONFIG"
  echo "========================================================"
  echo "Login on OCP Cluster ($KUBECONFIG)..."
  cat "$OCP_KUBEADMIN_PASSWD" | oc login -u kubeadmin
  
  echo "Getting the list of projects (excluding *default*, *openshift*, and *kube*) and storing on global variable OCP_PROJECT."
  OCP_PROJECTS=$(oc get project --no-headers | awk '!/default|openshift|kube/ {print $1}') 
}

function import_objects {
  OBJECT_NAME=$1
  OBJECT_NAME_FOR_PATH=`echo "$1" | awk '{print tolower($0)}'`

  echo "Creating $OBJECT_NAME objects on EKS Cluster..."
  for NAMESPACE in $(ls $WORKING_DIR)
  do 
    for OBJECT in $(ls $WORKING_DIR/$NAMESPACE/$OBJECT_NAME_FOR_PATH)
    do 
      echo "Importing objects from $WORKING_DIR/$NAMESPACE/$OBJECT_NAME_FOR_PATH"
      kubectl apply -f $WORKING_DIR/$NAMESPACE/$OBJECT_NAME_FOR_PATH/$OBJECT -n $NAMESPACE
    done
  done
}
