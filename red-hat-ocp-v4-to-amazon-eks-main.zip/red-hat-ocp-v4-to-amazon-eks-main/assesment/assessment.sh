#!/bin/bash
export NAMESPACED_RESOURCES="
        networkpolicies
        ingresses
        configmaps
        endpoints
        limitranges
        persistentvolumeclaims
        pods
        podtemplates
        replicationcontrollers
        resourcequotas
        secrets
        serviceaccounts
        services
        daemonsets
        deployments
        replicasets
        statefulsets
        deploymentconfigs
        rolebindingrestrictions
        horizontalpodautoscalers
        machineautoscalers
        cronjobs
        jobs
        buildconfigs
        builds
        imagestreams
        rolebindings
        roles
        routes
        templates"

export CLUSTER_RESOURCES="
        apiservices
        builds
        clusterautoscalers
        clusteroperators
        clusterresourcequotas
        clusterrolebindings
        clusterroles
        clusterversions
        configs
        csidrivers
        csinodes
        customresourcedefinitions
        groups
        identities
        imagepruners
        images
        imagesignatures
        ingressclasses
        ingresses
        kubeletconfigs
        machineconfigpools
        machineconfigs
        mutatingwebhookconfigurations
        namespaces
        nodes
        oauths
        persistentvolumes
        priorityclasses
        projects
        provisionings
        runtimeclasses
        securitycontextconstraints
        storageclasses
        storagestates
        storageversionmigrations
        useridentitymappings
        users
        validatingadmissionpolicies
        validatingadmissionpolicybindings
        validatingwebhookconfigurations
        volumeattachments"

function do_assessment() {
    for PROJECT in $(oc get project -o name | cut -d/ -f2); do
        echo "Getting resources from OpenShift Projects $PROJECT";
        mkdir -p /tmp/OCP_ASSESSMENT/PROJECTS/$PROJECT;
        for OBJECT in $NAMESPACED_RESOURCES; do
            echo $OBJECT;
            oc -n $PROJECT get $OBJECT >> /tmp/OCP_ASSESSMENT/PROJECTS/$PROJECT/$OBJECT.yaml
        done
        echo '##################################################'
    done

    echo 'Getting Cluster resources'
    mkdir -p /tmp/OCP_ASSESSMENT/CLUSTER/
    for RESOURCE in $CLUSTER_RESOURCES; do
        echo $RESOURCE
        oc get $RESOURCE >> /tmp/OCP_ASSESSMENT/CLUSTER/$RESOURCE.yaml
    done
}

function do_full_assessment() {
    echo "Performing full assessment..."
    for PROJECT in $(oc get project -o name | cut -d/ -f2); do
        echo "Getting resources from OpenShift Projects $PROJECT";
        mkdir -p /tmp/OCP_ASSESSMENT/PROJECTS/_MANIFESTS/$PROJECT;
        for OBJECT in $NAMESPACED_RESOURCES; do
                echo $OBJECT;
                oc -n $PROJECT get $OBJECT -o yaml >> /tmp/OCP_ASSESSMENT/PROJECTS/_MANIFESTS/$PROJECT/$OBJECT.yaml
        done
        echo '##################################################'
    done

    echo 'Getting Cluster resources'
    mkdir -p /tmp/OCP_ASSESSMENT/CLUSTER/_MANIFESTS/
    for RESOURCE in $CLUSTER_RESOURCES; do
        echo $RESOURCE
        oc get $RESOURCE -o yaml > /tmp/OCP_ASSESSMENT/CLUSTER/_MANIFESTS/$RESOURCE.yaml
    done
}

function create_zip() {
    if [ -d "/tmp/OCP_ASSESSMENT" ]; then
        echo "Creating ZIP file..."
        tar -czf /tmp/ocp_assessment.tar.gz /tmp/OCP_ASSESSMENT
    else
        echo "No assessment data found. Skipping ZIP creation."
    fi
}

function usage() {
    echo "Usage: $0 [--full] [--zip] [--help]"
    echo ""
    echo "Options:"
    echo "  --full   Perform a complete assessment, meaning export all manifests as YAML files. Notice that this may output some sensitive information"
    echo "  --zip    Create a ZIP file of the assessment directory" 
    echo "  --help   Show this help message"
    echo ""
}

if [ "$1" == "--full" ] && [ "$2" == "--zip" ] || [ "$1" == "--zip" ] && [ "$2" == "--full" ] ; then
    do_full_assessment
    create_zip
elif [ "$1" == "--full" ]; then
    do_full_assessment
elif [ "$1" == "--zip" ]; then
    if [ -d "/tmp/OCP_ASSESSMENT" ]; then
      create_zip
    else
      do_assessment
      create_zip
    fi
elif [ "$1" == "--help" ]; then
    usage
    exit 0
elif [ -n "$1" ]; then
    echo "Error: Unrecognized option '$1'"
    usage
    exit 1
else
    do_assessment
fi
