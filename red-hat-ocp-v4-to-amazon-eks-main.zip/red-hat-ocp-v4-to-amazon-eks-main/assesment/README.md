# OpenShift Cluster Assessment

The goal of these scripts is to create a list of existing resources in an OpenShift cluster to help on the translation and build the guidance when migrating to Amazon EKS. The command provides two different levels of assessment. The **regular** approach, executed with no additional parameters as explained below, will perform a simple assessment to get the amount of all resources commonly used on the workloads together with some cluster-wide resources that are required for the correct operation of the platform. The **full** assessment approach, will provide a copy of all the listed manifests in `YAML` language. ***This may bring sensitive information on the configuration or workloads as well.***

> It's required that you're already logged in your OpenShift Cluster to perform this assessment.

The command usage works as follows. If no option is provided, the script will run the **regular** assessment.

```
Usage: assessment.sh [--full] | [--zip] | [--help]

Options:
  --full   Perform a complete assessment, meaning export all manifests as YAML files. Notice that this may output some sensitive information
  --zip    Create a ZIP file of the assessment directory
  --help   Show this help message
```
